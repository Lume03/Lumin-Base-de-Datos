# src/core/security.py
from datetime import datetime, timedelta, timezone
from typing import Optional
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi import Depends, HTTPException, status
from jose import JWTError, jwt # Para crear y verificar JWTs

from src.util.util_credenciales import obtenerAPI

# --- Configuración ---
SECRET_KEY = obtenerAPI("CONF-JWT-SECRET-KEY")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 500 # El tiempo que dura tu sesión (ej: 8 horas)

# --- 2. Configuración de GOOGLE (para que la use tu API de login) ---
# Lee las credenciales de Google que pusiste en tu .env
GOOGLE_CLIENT_ID = obtenerAPI("CONF-GOOGLE-CLIENT-ID")
GOOGLE_CLIENT_SECRET = obtenerAPI("CONF-GOOGLE-CLIENT-SECRET")
GOOGLE_REDIRECT_URI = "https://developers.google.com/oauthplayground"

# --- Validación de que todo cargó bien ---
if not SECRET_KEY:
    raise Exception("Error: JWT_SECRET_KEY no encontrada en .env. Inventa una clave larga y ponla ahí.")
if not GOOGLE_CLIENT_ID or not GOOGLE_CLIENT_SECRET or not GOOGLE_REDIRECT_URI:
    raise Exception("Error: Faltan credenciales de Google (CLIENT_ID, CLIENT_SECRET o REDIRECT_URI) en .env.")

# Esquema para que FastAPI sepa cómo buscar el token ("Bearer" token en el header Authorization)
oauth2_scheme = HTTPBearer()
#Devuelve un HTTPAuthorizationCredentials que contiene el esquema y credentials (el token)
# --- Funciones ---

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None): #data contiene la info que queremos guardar en el token
    """Crea un nuevo token JWT."""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(days=30)
    to_encode.update({"exp": expire}) # Añade tiempo de expiración
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(oauth2_scheme) # <-- 2. Cambia 'token: str' por esto
):
    """
    Dependencia para verificar el token JWT y obtener el ID de usuario.
    ...
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="No se pudieron validar las credenciales",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        # 3. Extrae el string del token desde el objeto 'credentials'
        token_string = credentials.credentials 
        
        # Decodifica el token usando la clave secreta
        payload = jwt.decode(token_string, SECRET_KEY, algorithms=[ALGORITHM]) # <-- 4. Usa el string
        
        # Extrae el ID de usuario (o lo que hayas guardado) del token
        user_id_str: str | None = payload.get("sub") # Usamos "sub" (subject) por convención
        if user_id_str is None:
            raise credentials_exception
            
        # Convierte el ID a entero (o tu tipo de dato)
        try:
            user_id = int(user_id_str)
        except ValueError:
             raise credentials_exception
            
        # Devuelve el ID del usuario autenticado
        return {"user_id": user_id} 

    except JWTError:
        raise credentials_exception