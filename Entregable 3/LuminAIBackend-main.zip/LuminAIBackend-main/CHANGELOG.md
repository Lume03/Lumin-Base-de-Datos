## [1.15.2](https://github.com/NickSalA/LuminAIBackend/compare/v1.15.1...v1.15.2) (2025-11-30)


### Bug Fixes

* set default value for run_manager in create_retriever_tool functions ([78da7d3](https://github.com/NickSalA/LuminAIBackend/commit/78da7d34f8e7e24a5a963f92ea2b0de497907028))

## [1.15.1](https://github.com/NickSalA/LuminAIBackend/compare/v1.15.0...v1.15.1) (2025-11-30)


### Bug Fixes

* correct wallet directory path in Dockerfile and update question types in flow_preguntas_practica.py ([7e6effd](https://github.com/NickSalA/LuminAIBackend/commit/7e6effd77ecdb8fd1d0ecc121a4156d2a2c9a5bb))

# [1.15.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.14.0...v1.15.0) (2025-11-30)


### Features

* update Dockerfile and .dockerignore, remove requirements.txt, and refactor security and session management ([c9b7b8a](https://github.com/NickSalA/LuminAIBackend/commit/c9b7b8a214913d93eafc6a5b25cd995e9276e26a))

# [1.14.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.13.0...v1.14.0) (2025-11-30)


### Features

* extend JWT access token expiration to 30 days and add initial Dockerfile and .dockerignore ([71632b9](https://github.com/NickSalA/LuminAIBackend/commit/71632b9b86876f94f746d60e6d999a360a094695))

# [1.13.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.12.0...v1.13.0) (2025-11-30)


### Features

* refine tutor agent prompt instructions for conciseness and structured explanations. ([844cbe7](https://github.com/NickSalA/LuminAIBackend/commit/844cbe75eba8317f13ad7031197bc04a85083ba8))

# [1.12.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.11.0...v1.12.0) (2025-11-30)


### Features

* Refactorizar feedback y retriever ([fc77276](https://github.com/NickSalA/LuminAIBackend/commit/fc7727609ddbea80d3ba0e55469356ce0b57ddd1))

# [1.11.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.10.3...v1.11.0) (2025-11-30)


### Features

* Enhance text cleaning and extraction in document processing ([f630171](https://github.com/NickSalA/LuminAIBackend/commit/f630171269c3335045770026fc52de00ab4cf1d0))

## [1.10.3](https://github.com/NickSalA/LuminAIBackend/compare/v1.10.2...v1.10.3) (2025-11-30)


### Bug Fixes

* Restore flujoTrabajo parameter in PromptSistema function for proper functionality ([5171b2e](https://github.com/NickSalA/LuminAIBackend/commit/5171b2e34b9946218213deff36eee01a36f06563))

## [1.10.2](https://github.com/NickSalA/LuminAIBackend/compare/v1.10.1...v1.10.2) (2025-11-30)


### Bug Fixes

* Improve response handling in ejecutar function for better output clarity ([cea4046](https://github.com/NickSalA/LuminAIBackend/commit/cea404675e1d4b7f3fb62664e363bf77ecab985b))

## [1.10.1](https://github.com/NickSalA/LuminAIBackend/compare/v1.10.0...v1.10.1) (2025-11-30)


### Bug Fixes

* Correct age type in user data models from string to integer ([edb6cc8](https://github.com/NickSalA/LuminAIBackend/commit/edb6cc8989ba0aee1d015f24a5349ac64736464d))

# [1.10.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.9.1...v1.10.0) (2025-11-29)


### Features

* Add toon-format package and update JSON encoding in flow files ([9bde0ab](https://github.com/NickSalA/LuminAIBackend/commit/9bde0ab3695594597eff806d65b4e6e91b22c2a9))

## [1.9.1](https://github.com/NickSalA/LuminAIBackend/compare/v1.9.0...v1.9.1) (2025-11-29)


### Bug Fixes

* Improve error handling and data structure in response evaluation and question generation flows ([0446410](https://github.com/NickSalA/LuminAIBackend/commit/04464106b0d239a8912eb2fe906f805deeb1c8ca))

# [1.9.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.8.4...v1.9.0) (2025-11-17)


### Features

* Refactor agent API and remove deprecated routes; update schemas for improved data handling ([a16b7ed](https://github.com/NickSalA/LuminAIBackend/commit/a16b7ed397b3e76b3d15bb2992b36591b8033ade))

## [1.8.4](https://github.com/NickSalA/LuminAIBackend/compare/v1.8.3...v1.8.4) (2025-11-12)


### Bug Fixes

* Refactor variable names and improve code formatting for clarity ([58d1269](https://github.com/NickSalA/LuminAIBackend/commit/58d126945ea167243621667210fedcfab0c4174d))

## [1.8.3](https://github.com/NickSalA/LuminAIBackend/compare/v1.8.2...v1.8.3) (2025-11-07)


### Bug Fixes

* Actualización de las respuestas y formateo JSON para la calificacion para mayor claridad ([c553335](https://github.com/NickSalA/LuminAIBackend/commit/c55333557c4c32f2db6411ad8966060b8c4e4bae))

## [1.8.2](https://github.com/NickSalA/LuminAIBackend/compare/v1.8.1...v1.8.2) (2025-11-06)


### Bug Fixes

* Preguntas generadas en formato JSON y reestructuracion del prompt de AgentePregunta ([b961356](https://github.com/NickSalA/LuminAIBackend/commit/b96135674437e3b194bb33d2b84f6567d5855f0d))

## [1.8.1](https://github.com/NickSalA/LuminAIBackend/compare/v1.8.0...v1.8.1) (2025-11-06)


### Bug Fixes

* Refactorizando la IA en Agente Respuestas y retroalimentación ([36a36a8](https://github.com/NickSalA/LuminAIBackend/commit/36a36a8d82ef9ea1b3b665ed39ab70e336729397))

# [1.8.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.7.1...v1.8.0) (2025-11-06)


### Features

* Implementar creación de agentes sin memoria y mejorar la gestión de sesiones en la API ([d24f59f](https://github.com/NickSalA/LuminAIBackend/commit/d24f59f3b7a24c544696bd00708094a1424f579b))

## [1.7.1](https://github.com/NickSalA/LuminAIBackend/compare/v1.7.0...v1.7.1) (2025-11-06)


### Bug Fixes

* Corrección de la forma en que se llamaba el config de la respuesta del agente ([2acc0c1](https://github.com/NickSalA/LuminAIBackend/commit/2acc0c1a899c3e03c0781e8eac3e6f0235d4a72e))

# [1.7.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.6.0...v1.7.0) (2025-11-06)


### Features

* Implementar CORS y sesión en la API, actualizar rutas y mejorar el modelo de lenguaje ([bdb7588](https://github.com/NickSalA/LuminAIBackend/commit/bdb75889142edd0bb4839519bab9130c0cbdf595))

# [1.6.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.5.0...v1.6.0) (2025-11-03)


### Features

* Mejora del prompt de respuesta y preguntas ([926a9d9](https://github.com/NickSalA/LuminAIBackend/commit/926a9d90b4ead598b2da9b222d3b133628402f60))

# [1.5.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.4.0...v1.5.0) (2025-10-31)


### Features

* Actualizar credenciales para la api de azure ([6d22d9d](https://github.com/NickSalA/LuminAIBackend/commit/6d22d9d38fec6ad65ec0a26e1bb0867a3404caf4))

# [1.4.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.3.0...v1.4.0) (2025-10-25)


### Features

* add IDE configuration directories to .gitignore ([8d0fc2b](https://github.com/NickSalA/LuminAIBackend/commit/8d0fc2b56cbc95e1523ea2fd9c1f5db47ab0b52d))

# [1.3.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.2.1...v1.3.0) (2025-10-09)


### Features

* corregir el tema de las funciones de los agentes - decidir la forma que se utiliza la BC ([ba8a6ce](https://github.com/NickSalA/LuminAIBackend/commit/ba8a6ce7e28ce7e513bd1caa76584ceebe2b17a9))

## [1.2.1](https://github.com/NickSalA/LuminAIBackend/compare/v1.2.0...v1.2.1) (2025-10-09)


### Bug Fixes

* Corrección del prompt de AgenteTutor ([1f68064](https://github.com/NickSalA/LuminAIBackend/commit/1f68064fc28934da76fce05dca0fc93ed9a5db60))

# [1.2.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.1.0...v1.2.0) (2025-10-08)


### Features

* implement database connection utility and enhance agent evaluation flow ([82ecd9a](https://github.com/NickSalA/LuminAIBackend/commit/82ecd9a48176c78832354a19d392f780c93289aa))

# [1.1.0](https://github.com/NickSalA/LuminAIBackend/compare/v1.0.0...v1.1.0) (2025-10-01)


### Features

*  añadido estructura de agente tutor e implementacion de tool de retriever ([fdff43f](https://github.com/NickSalA/LuminAIBackend/commit/fdff43f8c59a220144179ebe150d18bf07da1ab7))

# 1.0.0 (2025-09-30)


### Features

* creación de util: llm, retriever, keyvault y sincronización de documentos por metadatos. Actualización de .gitignore y README.md ([27760a3](https://github.com/NickSalA/LuminAIBackend/commit/27760a33debc1bb8eed7ebbd692f133a66bfa6fe))
